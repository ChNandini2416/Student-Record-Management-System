import java.util.ArrayList;
import java.util.Scanner;

class Student {
    String id;
    String name;
    double marks;

    public Student(String id, String name, double marks) {
        this.id = id;
        this.name = name;
        this.marks = marks;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Marks: " + marks;
    }
}

public class StudentRecordManagementSystem {
    private ArrayList<Student> studentRecords;
    private Scanner scanner;

    public StudentRecordManagementSystem() {
        this.studentRecords = new ArrayList<>();
        this.scanner = new Scanner(System.in);
    }

    public void addStudentRecord() {
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        System.out.print("Enter student marks: ");
        double marks = scanner.nextDouble();
        scanner.nextLine(); // Consume newline left-over

        studentRecords.add(new Student(id, name, marks));
        System.out.println("Student record added successfully!");
    }

    public void viewStudentRecords() {
        if (studentRecords.isEmpty()) {
            System.out.println("No student records found!");
        } else {
            for (Student student : studentRecords) {
                System.out.println(student);
            }
        }
    }

    public void updateStudentRecord() {
        System.out.print("Enter student ID to update: ");
        String id = scanner.nextLine();

        for (Student student : studentRecords) {
            if (student.id.equals(id)) {
                System.out.print("Enter new student name: ");
                student.name = scanner.nextLine();
                System.out.print("Enter new student marks: ");
                student.marks = scanner.nextDouble();
                scanner.nextLine(); // Consume newline left-over
                System.out.println("Student record updated successfully!");
                return;
            }
        }
        System.out.println("Student record not found!");
    }

    public void deleteStudentRecord() {
        System.out.print("Enter student ID to delete: ");
        String id = scanner.nextLine();

        studentRecords.removeIf(student -> student.id.equals(id));
        System.out.println("Student record deleted successfully!");
    }

    public void run() {
        while (true) {
            System.out.println("Student Record Management System");
            System.out.println("1. Add Student Record");
            System.out.println("2. View Student Records");
            System.out.println("3. Update Student Record");
            System.out.println("4. Delete Student Record");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over

            switch (choice) {
                case 1:
                    addStudentRecord();
                    break;
                case 2:
                    viewStudentRecords();
                    break;
                case 3:
                    updateStudentRecord();
                    break;
                case 4:
                    deleteStudentRecord();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    public static void main(String[] args) {
        StudentRecordManagementSystem system = new StudentRecordManagementSystem();
        system.run();
    }
}